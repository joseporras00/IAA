# -*- coding: utf-8 -*-
"""
Numpy examples
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

########################################
# SERIES
########################################


"""
Series is a one-dimensional labeled array capable of holding any data type
(integers, strings, floating point numbers, Python objects, etc.). The axis labels
are collectively referred to as the index. The basic method to create a Series is
to call:

    s = pd.Series(data, index=index)
    
Here, data can be many different things:
                                        a Python dict
                                        an ndarray
                                        a scalar value (like 5)
    
"""

s1 = pd.Series(np.random.randn(5), index=['a', 'b', 'c', 'd', 'e'])

#Series can be instantiated from dicts:
d = {'b':1, 'a':0, 'c':2};

s2=  pd.Series(d);

"""
Series acts very similarly to a ndarray, and is a valid argument to most NumPy
functions. However, operations such as slicing will also slice the index.
"""

print(np.exp(s1));
print('----------');
print(s1[0]);
print('----------')
print(s1[s1 > s1.median()]);
print('----------')
print( s1[[4,3,1]]);

########################################
# DataFrame
########################################
"""
DataFrame is a 2-dimensional labeled data structure with columns of
potentially different types. You can think of it like a spreadsheet or SQL
table, or a dict of Series objects. It is generally the most commonly used
pandas object. Like Series, DataFrame accepts many different kinds of input:
Dict of 1D ndarrays, lists, dicts, or Series
2-D numpy.ndarray
Structured or record ndarray
A Series
Another DataFrame
➢ Along with the data, you can optionally pass index (row labels) and columns
(column labels) arguments. If you pass an index and/or columns, you are
guaranteeing the index and/or columns of the resulting DataFrame. Thus, a
dict of Series plus a specific index will discard all data not matching up to the
passed index.
➢ If axis labels are not passed, they will be constructed from the input data
based on common sense rules.
"""

# Creating a DataFrame by passing a NumPy array, with a datetime index and labeled columns:
    
dates = pd.date_range('20130101', periods=6);

df = pd.DataFrame(np.random.randn(6, 4), index=dates, columns=list("ABCD"));


# Creating a DataFrame by passing a dict of objects that can be converted to series-like.

df2 = pd.DataFrame({'A': 1.,
                    'B': pd.Timestamp('20130102'),
                    'C': pd.Series(1, index=list(range(4)), dtype='float32'),
                    'D': np.array([3] * 4, dtype='int32'),
                    'E': pd.Categorical(["test", "train", "test", "train"]),
                    'F': 'foo'});

# View the top and bottom rows of the frame:
print(df.head());
print('----------')
print( df.tail(3));
print('----------')

 
########################################
# DataFrame.to_numpy()
########################################

print(df.to_numpy());
print('----------')

########################################
# Summary of data
#describe() shows a quick statistic summary of your data:
########################################
print(df.describe());
print('----------')

########################################
# Transpose: DataFrame.T
########################################
print(df.T);
print('----------')


########################################
# Sorting
########################################

# Sorting by an axis
print( df.sort_index(axis=1, ascending=False));

#Sorting by a value
print( df.sort_values(by='B'));


########################################
# Selection
########################################

# We have the most basic indexing using []:

print(df['A']);

#You can pass a list of columns to [] to select columns in that order. Multiple columns can also be set in this manner

print( df[['B', 'A']]);

########################################
# What is difference between iloc and loc in Pandas?
########################################

df3 = pd.DataFrame({'Age': [30, 20, 22, 40, 32, 28, 39],
                   'Color': ['Blue', 'Green', 'Red', 'White', 'Gray', 'Black',
                             'Red'],
                   'Food': ['Steak', 'Lamb', 'Mango', 'Apple', 'Cheese',
                            'Melon', 'Beans'],
                   'Height': [165, 70, 120, 80, 180, 172, 150],
                   'Score': [4.6, 8.3, 9.0, 3.3, 1.8, 9.5, 2.2],
                   'State': ['NY', 'TX', 'FL', 'AL', 'AK', 'TX', 'TX']
                   },
                  index=['Jane', 'Nick', 'Aaron', 'Penelope', 'Dean',
                         'Christina', 'Cornelia'])
 
print("\n -- loc -- \n")
print(df3.loc[df3['Age'] < 30, ['Color', 'Height']])
 
print("\n -- iloc -- \n")
print(df3.iloc[(df3['Age'] < 30).values, [1, 3]])

########################################
# Missing data
########################################

#>Pandas primarily uses the value np.nan to represent missing data. It is by default not included in computations.
#➢ To drop any rows that have missing data.
df1 = df.reindex(index=dates[0:4], columns=list(df.columns) + ['E'])

print(df1);
df1.loc[dates[0]:dates[1], 'E'] = 1;
print(df1);

#Filling missing data

print( df1.fillna(value=5))

########################################
#Plot histograms
########################################

df = pd.DataFrame(np.random.randint(1, 7, 6000), columns = ['one'])
df['two'] = df['one'] + np.random.randint(1, 7, 6000)
df.plot.hist(bins=12, alpha=0.5)
plt.show()

#All attributes at the same time
df.hist()
plt.show()

########################################
#Reading and writting: Excel
########################################
df.to_excel('foo.xlsx')
df5=pd.read_excel('foo.xlsx', 'Sheet1', index_col=None, na_values=['NA'])








