#P2ej2
import numpy as np
import pandas as pd
from scipy.io.arff import loadarff
import matplotlib.pyplot as plt

df=pd.read_csv("winequality-white.csv")

df.hist()
plt.show()

