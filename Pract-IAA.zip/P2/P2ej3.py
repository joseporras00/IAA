#P2ej3
import numpy as np
import pandas as pd
from scipy.stats import poisson
from scipy.io.arff import loadarff
import matplotlib.pyplot as plt

df=pd.read_csv("winequality-red.csv")
X=poisson(mu=4.5)
num=df.columns
f,ax=plt.subplots(ncols=num)
f.subplots_adjust(wspace=0.05)
df.hist(

for k,a in enumerate(df):
    a.scatter(bins[:-1],X.pmf(bins[:-1]),color='red',zorder=3)
    a.set_tittle(df[k],loc='left',fontsize=20)


