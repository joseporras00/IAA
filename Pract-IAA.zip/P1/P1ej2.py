#Prac1 ej2
import random
import numpy as N


filas=int(input("Dime numero de filas: "))
columnas=int(input("Dime numero de columnas: "))

a=N.random.rand(filas,columnas)
print(a)

print("\nEl mínimo es: ",a.min(axis=None))
print("\nEl máximo es: ",a.max(axis=None))


#producto escalar 2 vectores
fila1=int(input("Dime fila 1 para el angulo: "))
fila2=int(input("Dime fila 2 para el angulo: "))
v1=a[fila1]
v2=a[fila2]
norma1=N.linalg.norm(v1)
norma2=N.linalg.norm(v2)
resultado=N.dot(v1,v2)/(norma1*norma2)
angulo=N.rad2deg(N.arccos(resultado))

print("\nEl angulo es: ",angulo)
