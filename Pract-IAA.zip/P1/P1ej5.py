#Pract1 ej5
import numpy as N

matriz=N.loadtxt("matriz.txt",delimiter="\t")

print(matriz, "\n")

print("La inversa es: \n")
inv_a=N.linalg.inv(matriz)
print(inv_a)

print("Y la multiplicación de estas es: ")
mult_a=N.matmul(matriz,inv_a)
print(mult_a)

